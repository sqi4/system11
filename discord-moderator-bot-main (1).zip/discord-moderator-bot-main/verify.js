module.exports = {
    code: "discord.gg/wicks",
    token: "",
    PORT:3000
};
